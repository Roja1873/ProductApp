package com.cg.proapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.proapp.bean.Product;
import com.cg.proapp.dao.ProductDao;
@Service
public class ProductServiceImpl implements ProductService {
@Autowired
ProductDao productDao;
	@Override
	public List<Product> getAllProducts() {
	
		return productDao.findAll();
	}

	@Override
	public Product getProductById(int id) {
		// TODO Auto-generated method stub
		return productDao.findById(id).get();
	}

	@Override
	public void updateProduct(Product pro) {
		
		productDao.save(pro);
	}

	@Override
	public void addProduct(Product pro) {
		productDao.save(pro);
		
	}

	@Override
	public void deleteProduct(int id) {
		productDao.deleteById(id);
		
	}

	@Override
	public List<Product> getProductByCategory(String category) {
		
		return productDao.getProductByCategory(category);
	}

}
